﻿#include "PlayerGui.h"
using namespace juce;

PlayerGUI::PlayerGUI()
{
    // Keep original buttons + listeners (do not remove)
    for (auto* btn : { &loadButton, &restartButton , &stopButton, &playButton, &pauseButton , &startButton, &endButton, &muteButton })
    {
        btn->addListener(this);
        addAndMakeVisible(btn);
    }

    // A-B and loop buttons (Feature 10 & 4)
    addAndMakeVisible(setAButton);
    setAButton.addListener(this);

    addAndMakeVisible(setBButton);
    setBButton.addListener(this);

    addAndMakeVisible(abLoopButton);
    abLoopButton.addListener(this);

    addAndMakeVisible(loopButton);
    loopButton.addListener(this);

    // Position slider (existing)
    addAndMakeVisible(positionSlider);
    positionSlider.setRange(0.0, 1.0, 0.0001);
    positionSlider.setSliderStyle(juce::Slider::LinearHorizontal);
    positionSlider.setTextBoxStyle(juce::Slider::NoTextBox, false, 0, 0);
    positionSlider.addListener(this);

    addAndMakeVisible(positionLabel);
    positionLabel.setJustificationType(juce::Justification::centredLeft);
    positionLabel.setMinimumHorizontalScale(1.0f);

    // Volume (existing) and keep mute logic
    volumeSlider.setRange(0.0, 1.0, 0.01);
    volumeSlider.setValue(previousVolume);
    volumeSlider.addListener(this);
    addAndMakeVisible(volumeSlider);

    // Feature 6: speed slider
    speedSlider.setRange(0.5, 2.0, 0.01);
    speedSlider.setValue(1.0);
    speedSlider.addListener(this);
    addAndMakeVisible(speedSlider);

    addAndMakeVisible(speedLabel);
    speedLabel.setText("Speed: 1.0x", juce::dontSendNotification);

    // Feature 9: progress bar
    addAndMakeVisible(progressBar);

    // Feature 5: metadata label
    addAndMakeVisible(metadataLabel);
    metadataLabel.setColour(juce::Label::textColourId, juce::Colours::white);
    metadataLabel.setJustificationType(juce::Justification::topLeft);
    metadataLabel.setColour(juce::Label::backgroundColourId, juce::Colours::transparentBlack);

    // Feature 8: playlist UI
    addAndMakeVisible(addToPlaylistButton);
    addToPlaylistButton.addListener(this);
    addAndMakeVisible(playlistBox);
    playlistBox.setModel(this);

    startTimerHz(10);
}

PlayerGUI::~PlayerGUI()
{
    stopTimer();
}

void PlayerGUI::resized()
{
    int x = 20;
    int y = 20;
    int h = 35;
    int gap = 10;

    loadButton.setBounds(x, y, 100, h);
    addToPlaylistButton.setBounds(x + 110, y, 140, h);
    y += h + gap;

    playlistBox.setBounds(x, y, 260, 150);
    y += 160;

    playButton.setBounds(x, y, 80, h);
    pauseButton.setBounds(x + 90, y, 80, h);
    stopButton.setBounds(x + 180, y, 80, h);
    restartButton.setBounds(x + 270, y, 100, h);
    y += h + gap;

    startButton.setBounds(x, y, 110, h);
    endButton.setBounds(x + 120, y, 110, h);
    loopButton.setBounds(x + 240, y, 80, h);
    y += h + gap;

    setAButton.setBounds(x, y, 110, h);
    setBButton.setBounds(x + 120, y, 110, h);
    abLoopButton.setBounds(x + 240, y, 100, h);
    y += h + gap;

    positionSlider.setBounds(x, y, getWidth() - 40 - 70, 20);
    positionLabel.setBounds(getWidth() - 110, y, 70, 20);
    y += 30;

    volumeSlider.setBounds(x, y, getWidth() - 40, 20);
    y += 30;

    // speed slider
    speedSlider.setBounds(x, y, getWidth() - 140, 20);
    speedLabel.setBounds(getWidth() - 110, y, 90, 20);
    y += 30;

    progressBar.setBounds(x, y, getWidth() - 40, 18);
    y += 30;

    metadataLabel.setBounds(getWidth() - 360, 20, 340, getHeight() - 40);
}

void PlayerGUI::prepareToPlay(int samplesPerBlockExpected, double sampleRate)
{
    playerAudio.prepareToPlay(samplesPerBlockExpected, sampleRate);
}

void PlayerGUI::getNextAudioBlock(const juce::AudioSourceChannelInfo& bufferToFill)
{
    playerAudio.getNextAudioBlock(bufferToFill);
}

void PlayerGUI::releaseResources()
{
    playerAudio.releaseResources();
}

void PlayerGUI::paint(juce::Graphics& g)
{
    g.fillAll(juce::Colours::darkgrey);
}

void PlayerGUI::buttonClicked(juce::Button* button)
{
    if (button == &loadButton)
    {
        fileChooser = std::make_unique<juce::FileChooser>("Select audio file...", juce::File{}, "*.mp3;*.wav");
        fileChooser->launchAsync(juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles,
            [this](const juce::FileChooser& chooser)
            {
                auto file = chooser.getResult();
                if (file.existsAsFile())
                {
                    playerAudio.loadFile(file);
                    metadataLabel.setText(playerAudio.getMetadataInfo(), juce::dontSendNotification);
                }
            });
    }

    if (button == &addToPlaylistButton)
    {
        fileChooser = std::make_unique<juce::FileChooser>("Add to playlist...", juce::File{}, "*.mp3;*.wav");
        fileChooser->launchAsync(juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectMultipleItems,
            [this](const juce::FileChooser& chooser)
            {
                auto results = chooser.getResults();
                for (auto& f : results)
                {
                    playlist.add(f.getFileName());
                    playlistFiles.add(f);
                }
                playlistBox.updateContent();
            });
    }

    if (button == &restartButton)
    {
        playerAudio.play();
    }

    if (button == &stopButton)
    {
        playerAudio.stop();
        playerAudio.setPosition(0.0);
    }

  
    if (button == &muteButton)
    {
        if (!isMuted)
        {
            previousVolume = (float)volumeSlider.getValue();
            playerAudio.setGain(0.0f);
            isMuted = true;
            muteButton.setButtonText("Unmute");
        }
        else
        {
            playerAudio.setGain(previousVolume);
            isMuted = false;
            muteButton.setButtonText("Mute");
        }
    }

  
    if (button == &playButton)
        playerAudio.play();

    if (button == &pauseButton)
        playerAudio.pause();

   
    if (button == &startButton)
        playerAudio.setPosition(0.0);

    if (button == &endButton)
        playerAudio.setPosition(playerAudio.getLength());

   
    if (button == &loopButton)
    {
        bool loopOn = loopButton.getToggleState();
        playerAudio.setLooping(loopOn);
        if (loopOn) DBG("Loop ON"); else DBG("Loop OFF");
    }

   
    if (button == &setAButton)
    {
        pointA = playerAudio.getPosition();
        DBG("Set A at: " << pointA);
    }

    if (button == &setBButton)
    {
        pointB = playerAudio.getPosition();
        DBG("Set B at: " << pointB);
    }

    if (button == &abLoopButton)
    {
        isABLooping = abLoopButton.getToggleState();
        if (isABLooping) DBG("A-B Loop Activated"); else DBG("A-B Loop Deactivated");
    }
}

void PlayerGUI::sliderValueChanged(juce::Slider* slider)
{
    if (slider == &volumeSlider)
    {
        playerAudio.setGain((float)slider->getValue());
    }
    else if (slider == &speedSlider)
    {
        double newSpeed = slider->getValue();
        playerAudio.setSpeed(newSpeed);
        speedLabel.setText(juce::String::formatted("Speed: %.2fx", newSpeed), juce::dontSendNotification);
    }
    else if (slider == &positionSlider)
    {
        if (playerAudio.getLength() > 0.0)
        {
            double total = playerAudio.getLength();
            double seconds = positionSlider.getValue() * total;
            int s = (int)std::round(seconds);
            int mins = s / 60;
            int secs = s % 60;
            positionLabel.setText(juce::String::formatted("%02d:%02d", mins, secs), juce::dontSendNotification);
        }
    }
}

void PlayerGUI::sliderDragStarted(juce::Slider* slider)
{
    if (slider == &positionSlider)
        isDraggingPosition = true;
}

void PlayerGUI::sliderDragEnded(juce::Slider* slider)
{
    if (slider == &positionSlider)
    {
        isDraggingPosition = false;
        double total = playerAudio.getLength();
        if (total > 0.0)
        {
            double newPos = positionSlider.getValue() * total;
            playerAudio.setPosition(newPos);
        }
    }
}

void PlayerGUI::timerCallback()
{
    if (!isDraggingPosition)
    {
        double total = playerAudio.getLength();
        if (total > 0.0)
        {
            double pos = playerAudio.getPosition();
            double norm = pos / total;
            positionSlider.setValue(norm, juce::dontSendNotification);

            int s = (int)std::round(pos);
            int mins = s / 60;
            int secs = s % 60;
            positionLabel.setText(juce::String::formatted("%02d:%02d", mins, secs), juce::dontSendNotification);

            // Update progress bar (Feature 9)
            progress = norm;
            progressBar.repaint();
        }
        else
        {
            positionSlider.setValue(0.0, juce::dontSendNotification);
            positionLabel.setText("00:00", juce::dontSendNotification);
            progress = 0.0;
            progressBar.repaint();
        }
    }

    // A-B loop enforcement (Feature 10)
    if (isABLooping && pointB > pointA)
    {
        double currentPos = playerAudio.getPosition();
        if (currentPos >= pointB)
        {
            playerAudio.setPosition(pointA);
            playerAudio.play();
        }
    }
}

int PlayerGUI::getNumRows()
{
    return playlist.size();
}

void PlayerGUI::paintListBoxItem(int rowNumber, juce::Graphics& g, int width, int height, bool rowIsSelected)
{
    if (rowIsSelected)
        g.fillAll(juce::Colours::lightblue);
    g.setColour(juce::Colours::white);
    if (isPositiveAndBelow(rowNumber, playlist.size()))
        g.drawText(playlist[rowNumber], 5, 0, width, height, juce::Justification::centredLeft);
}

void PlayerGUI::selectedRowsChanged(int lastRowSelected)
{
    if (isPositiveAndBelow(lastRowSelected, playlistFiles.size()))
    {
        auto file = playlistFiles[lastRowSelected];
        playerAudio.loadFile(file);
        metadataLabel.setText(playerAudio.getMetadataInfo(), juce::dontSendNotification);
    }
}
